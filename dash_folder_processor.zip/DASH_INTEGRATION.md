# Use your EXISTING Dash UI

This package contains NO new UI. Put camera.py, folder_processor.py and
camera_config.json alongside your existing Dash backend.
Install: pip install numpy scipy pillow tifffile

Create one processor instance at module scope in your backend:

```python
from folder_processor import FolderProcessor

processor = FolderProcessor(
    config_path=r"C:\MyApp\camera_config.json",
    input_parent=r"C:\Basler\incoming",
    output_parent=r"C:\Basler\processed",
    include_existing=False,   # True to replay all existing images for testing
)
```

Inside your EXISTING Start Camera callback, BEFORE starting acquisition:

```python
started = processor.start()  # nonblocking; False if already running/stopping
# Keep your existing code that starts the cameras here.
# It must write *_even.tif and *_odd.tif pairs into input_parent.
# If camera startup fails, call processor.stop() in that exception handler.
```

Inside your EXISTING Stop Camera callback:

```python
# First run your existing code to stop camera acquisition and drain its writers.
processor.stop()  # requests clean shutdown without blocking the Dash callback
```

At backend shutdown use processor.stop(wait=True). If you need to process the
last files written by the camera, let the watcher consume them before Stop;
Stop completes the current pair but does not drain all files remaining on disk.
To recover a backlog, start a fresh session with include_existing=True.

Read processor.status() from any EXISTING status callback. It returns state,
running, error, and the latest 100 messages. No Dash components or callback IDs
are prescribed; keep your current components and callback structure. Existing
callbacks must still return whatever outputs your app already expects.

start() ignores duplicate starts while processing/stopping. stop() is safe to
repeat. A fresh start creates new output sessions. include_existing=False
captures a baseline synchronously before starting the worker: call start BEFORE
acquisition so the first frames are not skipped. An existing filename that is
overwritten is NOT treated as a new frame. New acquisition directories allow
frame counters to restart; do not reset counters within the same capture folder.

Run this controller in ONE backend process. For Dash debug mode disable the
reloader (use_reloader=False). Multiple Gunicorn workers/replicas each have their
own instance; use a dedicated processing service if your deployment has multiple
workers. Do not launch processing at module import time.

## Input/output and settings

Input: pairs named 00000028_even.tif and 00000028_odd.tif. For multiple cameras,
use c1, c2, ... directories under input_parent, or camera-prefixed filenames.
The watcher recursively watches new files and acquisition directories.
It waits for both files to settle, and keeps each pair in source-frame order.
Detection uses the even image; both images are saved for every selected frame.

Output: a timestamped session contains timestamped sample folders. Each sample
folder directly contains ALL cameras' even/odd TIFFs, JSON and CSV. There are
NO camera/parity/preview subfolders INSIDE a sample. Diagnostic directories live
separately at session level. Names f00000028_c1_even.tif sort by source frame,
camera, then parity. Images are grouped whole; they are not cropped/stiched.

The included config has one camera, column splitting (split_axis=1), horizontal
scan (scan_axis=1), and raw scan scale 8.334 px/mm (= split scale 4.167).
The output path passed to FolderProcessor overrides output_root from JSON.
Cross-direction scale is null until calibrated. Set num_cameras=6 for six cameras.
Unverified multi-camera association groups product ordinals provisionally;
verified association requires shared trigger origin and calibrated offsets/scales.

The folder processor is separate from your camera acquisition. camera.py is
provided as its processing engine, but your existing Start Camera callback can
keep using your current acquisition implementation. Actual changes to your Dash
callback file require that file; this package supplies the backend call interface.
