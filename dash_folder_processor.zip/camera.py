"""Basler line-scan acquisition, LED splitting, live product tracking and measurement.

Python >=3.10. Install: pip install numpy scipy pillow tifffile pypylon
pypylon is needed only for live acquisition; tifffile is optional for simple TIFFs.

Quick start:
  python camera.py --write-config camera_config.json
  # Edit paths, split_axis, scan_axis, serials and calibration in that JSON.
  python camera.py --config camera_config.json
  python camera.py --config camera_config.json --offline saved_frames
  python camera.py --config camera_config.json --offline saved_frames --already-split even
  python camera.py --self-test

Offline layout: INPUT/c1/*.tif, INPUT/c2/*.tif, ... (or INPUT/*.tif for c1).
Legacy camera_0, camera_1 folders map to c1, c2. Filenames must contain an index,
e.g. 00000016.tif or c1_f00000016_even.tif. Already-split input must use the
--already-split option; it is never split a second time. Use original raw frame
indices, not independent counters for each LED image. One parity per replay.

Axes refer to the image AFTER rotation/flip: split_axis=0 splits rows, =1 columns;
scan_axis=0 means conveyor movement along image y; =1 means along image x.
Set rotation_k (np.rot90 quarter turns) and flips so scan coordinates increase
with conveyor travel. Coordinate X is across the conveyor, Y is along travel.
Each camera has separate RAW-pixel scales across/along travel. Splitting changes
sampling, not those scales; parity and stride are mapped back automatically.

For Mono12 stored as uint16 set input_max_value=4095; default scales by dtype.
For already-split images with an odd original raw extent, configure
already_split_raw_shape=[raw_height, raw_width]. Even/odd names refer to LOCAL
indices; an odd number of raw scan lines changes the physical LED phase between
frames (recorded as local_even_global_line_parity).

Camera x_offset_mm/y_offset_mm are positions of its normalized raw-image origin
in a COMMON coordinate system at the same trigger origin. Offsets must include
camera overlaps and longitudinal displacement; never sum camera widths blindly.
frame_stride_px defaults to the raw scan extent (nonoverlapping continuous frames).
Set it for a known frame overlap or gap. Variable frame shape is rejected.

synchronization='unverified' groups camera product ordinals provisionally.
'shared_trigger' is an assertion that camera frame zero and line positions share
one trigger/encoder origin. Products are then matched by calibrated entry Y within
association_tolerance_mm; unmatched entries stay in separate products. Enable ONLY after verifying that physically. Metadata
records device block IDs/timestamps and missing-frame errors; these are not proof
of synchronization. An acquisition failure invalidates sequence geometry rather
than silently producing trusted dimensions. Offline gaps are retained explicitly.

The detector targets straight, dark borders with brighter shoulders. Tune detector
thresholds for your lighting. It reports visible segments, not guaranteed material
edges; clipped/unresolved borders remain incomplete. Inner/outer measurement is
configurable. Every successful source frame is saved; product folders contain
linked/copied even/odd images, frames.csv, detections.jsonl and product.json.
Products are finalized after all required active cameras see an exit, or marked
incomplete at shutdown. Intermediate frames without an edge are retained.

Session outputs: raw/, split/, products/, previews/, detections/, frames.jsonl,
errors.jsonl, session.json. Frame previews and detections are saved independently
of product assignment, including unclassified bands and frames with no accepted bands.
No camera connection or output-directory creation occurs on import.
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
import logging
import os
import queue
import re
import shutil
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage as ndi

DEFAULT_CONFIG = {
    'output_root': r'C:\Users\Administrator\Documents\Basler\captures',
    'pfs_file': r'C:\Users\Administrator\Documents\Basler\Config\r2L4096-29gm_40653992.pfs',
    'num_cameras': 6,
    'grab_timeout_ms': 1000,
    'queue_size': 32,
    'camera_max_num_buffer': 32,
    'stream_frame_retention_ms': 200,
    'stream_packet_timeout_ms': 100,
    'save_raw': True,
    'flat_product_folders': False,
    'save_previews': True,
    'split_axis': 0,
    'scan_axis': 0,
    'rotation_k': 0,
    'flip_x': False,
    'flip_y': False,
    'frame_stride_px': None,
    'detection_parity': 'even',
    'measurement_boundary': 'outer',
    'synchronization': 'unverified',
    'event_dedup_px': 8,
    'association_tolerance_mm': 5.0,
    'input_max_value': None,  # Set 4095 for unpacked Mono12 in uint16.
    'already_split_raw_shape': None,  # Optional [raw_height, raw_width], for odd raw extents.
    'detector': {
        'dark_threshold_8bit': 35,
        'min_contrast_8bit': 18,
        'min_border_width_px': 3,
        'max_border_width_px': 120,
        'min_line_fraction': 0.10,
        'opening_line_fraction': 0.12,
        'shoulder_gap_px': 15,
        'require_both_shoulders': True,
    },
    'cameras': [
        {'id': f'c{i}', 'serial': None, 'pfs_file': None,
         'grid_column': i - 1, 'cross_edge_role': 'auto',
         'pixels_per_mm_x': None, 'pixels_per_mm_y': None,
         'x_offset_mm': None, 'y_offset_mm': None,
         'required_for_completion': True}
        for i in range(1, 7)
    ],
}
EXTENSIONS = {'.tif', '.tiff', '.png', '.bmp', '.jpg', '.jpeg'}


def json_write(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temp, path)


def append_json(path, value):
    with Path(path).open('a', encoding='utf-8') as f:
        f.write(json.dumps(value, allow_nan=False) + '\n')


def load_config(path=None):
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    if path:
        supplied = json.loads(Path(path).read_text(encoding='utf-8'))
        detector = cfg['detector'] | supplied.get('detector', {})
        cfg.update(supplied)
        cfg['detector'] = detector
    for key in ('split_axis', 'scan_axis'):
        if cfg[key] not in (0, 1):
            raise ValueError(f'{key} must be 0 or 1')
    if cfg['detection_parity'] not in ('even', 'odd'):
        raise ValueError('detection_parity must be even or odd')
    if cfg['measurement_boundary'] not in ('inner', 'outer'):
        raise ValueError('measurement_boundary must be inner or outer')
    if cfg['synchronization'] not in ('unverified', 'shared_trigger'):
        raise ValueError('synchronization must be unverified or shared_trigger')
    if cfg['association_tolerance_mm'] <= 0:
        raise ValueError('association_tolerance_mm must be positive')
    if cfg['input_max_value'] is not None and cfg['input_max_value'] <= 0:
        raise ValueError('input_max_value must be positive')
    if cfg['already_split_raw_shape'] is not None and (
        len(cfg['already_split_raw_shape']) != 2 or min(cfg['already_split_raw_shape']) < 2):
        raise ValueError('already_split_raw_shape must be [raw_height, raw_width]')
    if cfg['num_cameras'] < 1 or cfg['queue_size'] < 1:
        raise ValueError('num_cameras and queue_size must be positive')
    if cfg['frame_stride_px'] is not None and cfg['frame_stride_px'] <= 0:
        raise ValueError('frame_stride_px must be positive')
    ids, serials, columns = set(), set(), set()
    for cam in cfg['cameras']:
        cid = cam['id']
        if not re.fullmatch(r'[A-Za-z0-9_-]+', cid) or cid in ids:
            raise ValueError(f'Invalid or duplicate camera ID: {cid}')
        ids.add(cid)
        col = cam['grid_column']
        if col in columns:
            raise ValueError('grid_column must be unique')
        columns.add(col)
        if cam.get('serial'):
            if str(cam['serial']) in serials:
                raise ValueError('Duplicate camera serial')
            serials.add(str(cam['serial']))
        if cam.get('cross_edge_role', 'auto') not in ('auto', 'left', 'right', 'both', 'none'):
            raise ValueError('Invalid cross_edge_role')
        for key in ('pixels_per_mm_x', 'pixels_per_mm_y'):
            if cam.get(key) is not None and cam[key] <= 0:
                raise ValueError(f'{cid}: {key} must be positive')
    if len(cfg['cameras']) < cfg['num_cameras']:
        raise ValueError('Add a cameras entry for each requested camera')
    d = cfg['detector']
    if not 1 <= d['min_border_width_px'] <= d['max_border_width_px']:
        raise ValueError('Invalid border-width range')
    for key in ('min_line_fraction', 'opening_line_fraction'):
        if not 0 < d[key] <= 1:
            raise ValueError(f'{key} must lie in (0, 1]')
    return cfg


def read_image(path):
    try:
        import tifffile
    except ImportError:
        with Image.open(path) as im:
            return np.array(im)
    return tifffile.imread(path) if Path(path).suffix.lower() in {'.tif', '.tiff'} else np.array(Image.open(path))


def save_image(path, image):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.stem + '.tmp.tif')
    try:
        import tifffile
    except ImportError:
        Image.fromarray(image).save(temp, format='TIFF')
    else:
        tifffile.imwrite(temp, image, compression=None)
    os.replace(temp, path)


def orient_image(image, cfg):
    im = np.rot90(image, int(cfg['rotation_k']))
    if cfg['flip_x']:
        im = np.flip(im, axis=1)
    if cfg['flip_y']:
        im = np.flip(im, axis=0)
    return np.ascontiguousarray(im)


def split_even_odd(image, axis=0):
    a, b = [slice(None)] * image.ndim, [slice(None)] * image.ndim
    a[axis], b[axis] = slice(0, None, 2), slice(1, None, 2)
    return {'even': np.ascontiguousarray(image[tuple(a)]),
            'odd': np.ascontiguousarray(image[tuple(b)])}


def gray8(image, input_max_value=None):
    if image.ndim == 3:
        image = image[..., :3].astype(np.float32).mean(axis=2)
    if image.ndim != 2:
        raise ValueError(f'Unsupported image shape {image.shape}')
    if image.dtype == np.uint8 and input_max_value is None:
        return image
    # Fixed bit-depth scaling, not frame-by-frame percentile normalization.
    if np.issubdtype(image.dtype, np.integer):
        scale = np.iinfo(image.dtype).max
    else:
        if not np.isfinite(image).all():
            raise ValueError('Nonfinite image data')
        scale = 1.0 if image.max() <= 1 else 255.0
    if input_max_value is not None:
        scale = float(input_max_value)
        if scale <= 0:
            raise ValueError('input_max_value must be positive')
    return np.clip(image.astype(np.float32) * (255 / scale), 0, 255).astype(np.uint8)


def runs(indices):
    if len(indices) == 0:
        return []
    return np.split(indices, np.flatnonzero(np.diff(indices) > 1) + 1)


def detect_frame_boundaries(image, cfg):
    """Return dark-band segments in image x/y coordinates; no invented edges."""
    gray = gray8(image, cfg.get('input_max_value'))
    d = cfg['detector']
    found = []
    for axis in (1, 0):  # x bands, then y bands
        along = 1 - axis
        max_width = int(d['max_border_width_px'])
        local_max = ndi.maximum_filter1d(gray, 2 * max_width + 1, axis=axis)
        mask = ((gray < d['dark_threshold_8bit']) &
                (local_max.astype(np.int16) - gray >= d['min_contrast_8bit']))
        length = max(3, int(gray.shape[along] * d['opening_line_fraction']))
        mask = ndi.maximum_filter1d(
            ndi.minimum_filter1d(mask, length, axis=along, mode='constant'),
            length, axis=along, mode='constant')
        coverage = mask.mean(axis=along)
        for group in runs(np.flatnonzero(coverage >= d['min_line_fraction'])):
            low, high = int(group[0]), int(group[-1]) + 1  # half-open band
            if not d['min_border_width_px'] <= high - low <= max_width:
                continue
            mid = (low + high - 1) // 2
            line = mask[:, mid] if axis == 1 else mask[mid, :]
            support = np.flatnonzero(line)
            if len(support) < length:
                continue
            gap = int(d['shoulder_gap_px'])
            before, after = low - gap, high - 1 + gap
            if before < 0 or after >= gray.shape[axis]:
                continue  # clipped band: insufficient shoulder evidence
            center = gray[:, mid] if axis == 1 else gray[mid, :]
            l = gray[:, before] if axis == 1 else gray[before, :]
            r = gray[:, after] if axis == 1 else gray[after, :]
            lc = l.astype(np.float32) - center
            rc = r.astype(np.float32) - center
            contrast = np.minimum(lc, rc) if d['require_both_shoulders'] else np.maximum(lc, rc)
            good = line & (contrast >= d['min_contrast_8bit'])
            support = np.flatnonzero(good)
            if len(support) / gray.shape[along] < d['min_line_fraction']:
                continue
            # Longest continuous support, bridging small illumination interruptions.
            closed = ndi.binary_closing(good, structure=np.ones(5))
            segments = runs(np.flatnonzero(closed))
            segment = max(segments, key=len, default=np.array([], dtype=int))
            if len(segment) < length:
                continue
            found.append({'axis': 'x' if axis == 1 else 'y',
                          'low': low, 'high': high,
                          'span_start': int(segment[0]), 'span_end': int(segment[-1]) + 1,
                          'coverage': float(len(support) / gray.shape[along]),
                          'contrast': float(np.median(contrast[support])),
                          'confidence': float(min(1, len(support) / gray.shape[along]) *
                                              min(1, np.median(contrast[support]) / 64)),
                          'side': None})
    # Corner intersections identify side from the direction of the perpendicular band.
    tolerance = max(10, 2 * d['max_border_width_px'])
    for edge in found:
        votes = []
        mid = (edge['low'] + edge['high']) / 2
        for other in found:
            if other['axis'] == edge['axis']:
                continue
            omid = (other['low'] + other['high']) / 2
            if not edge['span_start'] - tolerance <= omid <= edge['span_end'] + tolerance:
                continue
            ds, de = abs(mid - other['span_start']), abs(mid - other['span_end'])
            if min(ds, de) <= tolerance and abs(ds - de) > tolerance:
                votes.append('low' if ds < de else 'high')
        if votes and len(set(votes)) == 1:
            edge['side'] = ({'x': ('left', 'right'), 'y': ('top', 'bottom')}
                            [edge['axis']][0 if votes[0] == 'low' else 1])
    return found


def boundary_position(edge, side, convention):
    low_side = side in ('left', 'top')
    return float(edge['low'] if low_side == (convention == 'outer') else edge['high'])


def link_or_copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)


class ProductPipeline:
    """Single worker owns all mutable tracker state; acquisition threads only enqueue."""
    def __init__(self, cfg, session, cameras):
        self.cfg, self.session = cfg, Path(session)
        self.cameras = {c['id']: c for c in cameras}
        self.states = {cid: {'current': None, 'ordinal': 0, 'last_event': None,
                             'shape': None, 'last_index': None, 'last_block': None,
                             'sequence_valid': True} for cid in self.cameras}
        self.products = {}
        self.calibrated_association = (len(self.cameras) > 1 and
            cfg['synchronization'] == 'shared_trigger' and
            all(c.get('pixels_per_mm_y') and c.get('y_offset_mm') is not None
                for c in self.cameras.values()))
        self.required = {cid for cid, c in self.cameras.items() if c.get('required_for_completion', True)}
        if not self.required:
            self.required = set(self.cameras)

    def error(self, cid, message, frame_index=None):
        logging.error('%s: %s', cid, message)
        append_json(self.session / 'errors.jsonl', {'camera_id': cid, 'frame_index': frame_index,
                                                   'message': message, 'time_ns': time.time_ns()})

    def product(self, ordinal):
        if ordinal not in self.products:
            folder = (self.session / f'sample_{datetime.now():%Y%m%d_%H%M%S_%f}_{ordinal:04d}'
                      if self.cfg.get('flat_product_folders') else
                      self.session / 'products' / f'product_{ordinal:04d}')
            folder.mkdir(parents=True)
            self.products[ordinal] = {'id': ordinal, 'folder': folder, 'frames': {},
                                      'camera_results': {}, 'closed': False,
                                      'entry_anchor_mm': None,
                                      'association_verified': len(self.cameras) == 1}
        return self.products[ordinal]

    def start(self, cid, index, entry, incomplete=False):
        state = self.states[cid]
        state['ordinal'] += 1
        ordinal = state['ordinal']
        anchor = None
        if self.calibrated_association and entry is not None:
            cam = self.cameras[cid]
            anchor = cam['y_offset_mm'] + entry / cam['pixels_per_mm_y']
            matches = [p for p in self.products.values() if
                       p['entry_anchor_mm'] is not None and
                       cid not in p['camera_results'] and
                       abs(p['entry_anchor_mm'] - anchor) <= self.cfg['association_tolerance_mm']]
            if len(matches) > 1:
                raise ValueError('Ambiguous product association: reduce association_tolerance_mm')
            ordinal = matches[0]['id'] if matches else max(self.products, default=0) + 1
        elif self.calibrated_association:
            # An exit without an entry cannot be matched across cameras safely.
            ordinal = max(self.products, default=0) + 1
        track = {'ordinal': ordinal, 'start_frame': index, 'entry_px': entry,
                 'exit_px': None, 'cross_low': [], 'cross_high': [],
                 'incomplete_start': incomplete, 'sequence_valid': state['sequence_valid']}
        state['current'] = track
        product = self.product(ordinal)
        if anchor is not None:
            if product['entry_anchor_mm'] is None:
                product['entry_anchor_mm'] = anchor
            product['association_verified'] = True
        return track

    def raw_coordinate(self, coordinate, axis, parity, already_split):
        # Rotation/flip was applied before split, so these are normalized raw pixels.
        split_axis = self.cfg['split_axis']
        array_axis = 1 if axis == 'x' else 0
        if array_axis == split_axis:
            return 2 * coordinate + (0 if parity == 'even' else 1)
        return coordinate

    def process(self, cid, index, image, metadata=None, already_split=None, paired_odd=None):
        cfg, cam, state = self.cfg, self.cameras[cid], self.states[cid]
        metadata = dict(metadata or {})
        if state['last_index'] is not None and index <= state['last_index']:
            raise ValueError(f'{cid}: repeated/out-of-order source-frame index {index}')
        if state['last_index'] is not None and index != state['last_index'] + 1:
            state['sequence_valid'] = False
            self.error(cid, 'Missing source-frame indices; geometry marked untrusted', index)
        state['last_index'] = index
        block = metadata.get('block_id')
        if block not in (None, 0):
            previous = state['last_block']
            if previous is not None and block != previous + 1:
                state['sequence_valid'] = False
                self.error(cid, f'Device block discontinuity: {previous} -> {block}', index)
            state['last_block'] = block
        if metadata.get('sequence_error'):
            state['sequence_valid'] = False
        if image is None:
            self.invalidate_sequence(cid, metadata.get('error', 'Failed acquisition'), index)
            append_json(self.session / 'frames.jsonl', {'camera_id': cid, 'frame_index': index,
                        'status': 'failed_grab', **metadata})
            return
        image = orient_image(image, cfg)
        raw_shape = list(image.shape[:2])
        if already_split:
            if cfg['rotation_k'] or cfg['flip_x'] or cfg['flip_y']:
                raise ValueError('Already-split replay requires pre-oriented input and zero rotation/flips')
            raw_shape[cfg['split_axis']] *= 2
            if cfg.get('already_split_raw_shape'):
                raw_shape = list(cfg['already_split_raw_shape'])
                expected = list(raw_shape)
                a = cfg['split_axis']
                expected[a] = (expected[a] + (already_split == 'even')) // 2
                if expected != list(image.shape[:2]):
                    raise ValueError('already_split_raw_shape does not match input')
            views = {already_split: image}
            if paired_odd is not None:
                if already_split != 'even':
                    raise ValueError('Paired input requires even as the primary image')
                expected_odd = list(raw_shape)
                expected_odd[cfg['split_axis']] //= 2
                if list(paired_odd.shape[:2]) != expected_odd:
                    raise ValueError('Odd image shape does not match inferred raw shape')
                views['odd'] = paired_odd
        else:
            views = split_even_odd(image, cfg['split_axis'])
        if min(image.shape[:2]) < 2 or any(min(v.shape[:2]) < 2 for v in views.values()):
            raise ValueError('Frame/split image too small')
        if state['shape'] is not None and raw_shape != state['shape']:
            raise ValueError(f'{cid}: frame shape changed; cannot infer scan origin')
        state['shape'] = raw_shape
        scan_extent = raw_shape[cfg['scan_axis']]
        stride = cfg['frame_stride_px'] or scan_extent
        scan_origin = index * stride
        prefix = f'{cid}_f{index:08d}'
        paths = {}
        if cfg['save_raw'] and not already_split:
            raw_path = self.session / 'raw' / cid / f'{prefix}_raw.tif'
            save_image(raw_path, image)
        for parity, view in views.items():
            path = self.session / 'split' / cid / f'{prefix}_{parity}.tif'
            save_image(path, view)
            paths[parity] = str(path.relative_to(self.session))
        parity = already_split or cfg['detection_parity']
        detection_image = views[parity]
        edges = detect_frame_boundaries(detection_image, cfg)
        scan_axis = 'y' if cfg['scan_axis'] == 0 else 'x'
        cross_axis = 'x' if scan_axis == 'y' else 'y'
        scan_edges = sorted([e for e in edges if e['axis'] == scan_axis], key=lambda e: e['low'])
        cross_edges = [e for e in edges if e['axis'] == cross_axis]
        # Cross-camera role is configured; auto needs a corner or an established side.
        for e in cross_edges:
            role = cam.get('cross_edge_role', 'auto')
            if role == 'none':
                e['usable'] = False
                continue
            if role in ('left', 'right'):
                side = role
            else:
                low_names = ('left', 'top')
                if e['side']:
                    side = 'left' if e['side'] in low_names else 'right'
                else:
                    current = state['current']
                    known = []
                    coordinate = self.raw_coordinate((e['low'] + e['high']) / 2,
                                                     cross_axis, parity, already_split)
                    if current:
                        for label, key in [('left', 'cross_low'), ('right', 'cross_high')]:
                            if current[key]:
                                known.append((abs(coordinate - float(np.median(current[key]))), label))
                    nearest = min(known, default=(float('inf'), None))
                    if nearest[0] <= 2 * cfg['detector']['max_border_width_px']:
                        side = nearest[1]
                    elif role == 'both' and len(cross_edges) == 2:
                        side = 'left' if e is min(cross_edges, key=lambda b: b['low']) else 'right'
                    else:
                        e['usable'] = False
                        e['rejection'] = 'Cross side unresolved: configure camera cross_edge_role'
                        continue
            # Explicit roles do not override contradictory corner evidence.
            if role in ('left', 'right') and e['side']:
                observed = 'left' if e['side'] in ('left', 'top') else 'right'
                if observed != role:
                    e['usable'] = False
                    continue
            e['cross_side'], e['usable'] = side, True
        tracks = []
        current = state['current']
        if current:
            tracks.append(current)
        elif not scan_edges and any(e.get('usable') for e in cross_edges):
            # Acquisition may begin halfway through an object. Keep its frames,
            # but do not fabricate a missing entry coordinate.
            current = self.start(cid, index, None, incomplete=True)
            tracks.append(current)
        for e in scan_edges:
            # Debounce the same physical band appearing in overlapping source frames.
            center = scan_origin + self.raw_coordinate((e['low'] + e['high']) / 2, scan_axis, parity, already_split)
            previous = state['last_event']
            if previous is not None and abs(center - previous) <= cfg['event_dedup_px']:
                continue
            state['last_event'] = center
            entry_side = 'top' if scan_axis == 'y' else 'left'
            exit_side = 'bottom' if scan_axis == 'y' else 'right'
            current = state['current']
            if current is None:
                if e['side'] == exit_side:
                    current = self.start(cid, index, None, incomplete=True)
                    coordinate = boundary_position(e, exit_side, cfg['measurement_boundary'])
                    current['exit_px'] = scan_origin + self.raw_coordinate(coordinate, scan_axis, parity, already_split)
                    state['current'] = None
                    e['event'] = 'exit_incomplete'
                else:
                    current = self.start(cid, index, scan_origin + self.raw_coordinate(
                        boundary_position(e, entry_side, cfg['measurement_boundary']), scan_axis, parity, already_split))
                    e['event'] = 'entry'
            else:
                if e['side'] == entry_side:
                    # A second explicit entry means the old product has an unresolved exit.
                    current['incomplete_exit'] = True
                    if current not in tracks:
                        tracks.append(current)
                    current = self.start(cid, index, scan_origin + self.raw_coordinate(
                        boundary_position(e, entry_side, cfg['measurement_boundary']), scan_axis, parity, already_split))
                    e['event'] = 'entry_after_missing_exit'
                else:
                    current['exit_px'] = scan_origin + self.raw_coordinate(
                        boundary_position(e, exit_side, cfg['measurement_boundary']), scan_axis, parity, already_split)
                    state['current'] = None
                    e['event'] = 'exit'
            if current not in tracks:
                tracks.append(current)
        record = {'camera_id': cid, 'frame_index': index, 'raw_shape': raw_shape,
                  'scan_origin_px': scan_origin, 'grid_column': cam['grid_column'],
                  'split_axis': cfg['split_axis'], 'scan_axis': cfg['scan_axis'],
                  'detection_parity': parity, 'paths': paths, 'edges': edges,
                  'local_even_global_line_parity': int(scan_origin % 2) if cfg['split_axis'] == cfg['scan_axis'] else 0,
                  'tracking_status': ('assigned_to_product' if tracks else
                      'edges_detected_without_product_assignment' if edges else 'no_edges_detected'),
                  'detected_vertical_bands': sum(e['axis'] == 'x' for e in edges),
                  'detected_horizontal_bands': sum(e['axis'] == 'y' for e in edges),
                  'sequence_valid': state['sequence_valid'], **metadata}
        append_json(self.session / 'frames.jsonl', record)
        for track in tracks:
            self.add_frame(cid, index, track, record, cross_edges, scan_origin, parity, already_split)
        # Snapshot open products too, so partial work is reviewable during acquisition.
        for ordinal in {t['ordinal'] for t in tracks}:
            self.write_product(ordinal)
        if cfg['save_previews']:
            self.save_preview(detection_image, edges, cid, index, tracks)
        if edges and not tracks:
            logging.info('%s f%s: detected %s vertical / %s horizontal bands; '
                         'not assigned to a product (check scan_axis and boundary roles).',
                         cid, index, record['detected_vertical_bands'], record['detected_horizontal_bands'])
        detection_folder = self.session / 'detections' / cid
        detection_folder.mkdir(parents=True, exist_ok=True)
        json_write(detection_folder / f'{cid}_f{index:08d}.json', record)

    def add_frame(self, cid, index, track, record, cross_edges, scan_origin, parity, already_split):
        cfg = self.cfg
        scan_axis = 'y' if cfg['scan_axis'] == 0 else 'x'
        for e in cross_edges:
            if not e.get('usable'):
                continue
            # Only use side segments overlapping this product's visible scan interval.
            start = scan_origin + self.raw_coordinate(e['span_start'], scan_axis, parity, already_split)
            end = scan_origin + self.raw_coordinate(e['span_end'], scan_axis, parity, already_split)
            if track['entry_px'] is not None and end < track['entry_px']:
                continue
            if track['exit_px'] is not None and start > track['exit_px']:
                continue
            side = e['cross_side']
            coordinate = boundary_position(e, side, cfg['measurement_boundary'])
            raw = self.raw_coordinate(coordinate, e['axis'], parity, already_split)
            track['cross_low' if side == 'left' else 'cross_high'].append(raw)
        track['sequence_valid'] &= self.states[cid]['sequence_valid']
        product = self.product(track['ordinal'])
        row = index - track['start_frame']
        # Rows are relative per-camera frame positions, not a synchronization claim.
        key = f'{cid}:{index}'
        cam = self.cameras[cid]
        scan_mm = (cam['y_offset_mm'] + scan_origin / cam['pixels_per_mm_y']
                   if cam.get('pixels_per_mm_y') and cam.get('y_offset_mm') is not None else None)
        product['frames'][key] = {'camera_id': cid, 'frame_index': index,
                                  'scan_origin_px': scan_origin, 'scan_origin_mm': scan_mm,
                                  'camera_x_offset_mm': cam.get('x_offset_mm'),
                                  'grid_row': row, 'grid_column': self.cameras[cid]['grid_column'],
                                  'paths': record['paths'], 'edge_count': len(record['edges'])}
        folder = product['folder']
        for path in record['paths'].values():
            name = (f'f{index:08d}_{cid}_{Path(path).stem.rsplit("_", 1)[-1]}.tif'
                    if cfg.get('flat_product_folders') else Path(path).name)
            target = folder / name if cfg.get('flat_product_folders') else folder / cid / name
            link_or_copy(self.session / path, target)
        append_json(folder / 'detections.jsonl', record)
        product['camera_results'][cid] = copy.deepcopy(track)

    def calculate_dimensions(self, product):
        cfg, results = self.cfg, product['camera_results']
        per_camera = {}
        lows, highs, entries, exits = [], [], [], []
        reasons = []
        for cid, r in results.items():
            cam = self.cameras[cid]
            px, py = cam.get('pixels_per_mm_x'), cam.get('pixels_per_mm_y')
            lo = float(np.median(r['cross_low'])) if r['cross_low'] else None
            hi = float(np.median(r['cross_high'])) if r['cross_high'] else None
            entry, exit_ = r['entry_px'], r['exit_px']
            valid = r['sequence_valid']
            length = (exit_ - entry) / py if valid and py and entry is not None and exit_ is not None and exit_ > entry else None
            width = (hi - lo) / px if valid and px and lo is not None and hi is not None and hi > lo else None
            per_camera[cid] = {'width_mm': width, 'length_mm': length,
                               'cross_low_px': lo, 'cross_high_px': hi,
                               'entry_px': entry, 'exit_px': exit_,
                               'sequence_valid': valid,
                               'complete': entry is not None and exit_ is not None}
            if valid and px and cam.get('x_offset_mm') is not None:
                if lo is not None:
                    lows.append(cam['x_offset_mm'] + lo / px)
                if hi is not None:
                    highs.append(cam['x_offset_mm'] + hi / px)
            if valid and py and cam.get('y_offset_mm') is not None:
                if entry is not None:
                    entries.append(cam['y_offset_mm'] + entry / py)
                if exit_ is not None:
                    exits.append(cam['y_offset_mm'] + exit_ / py)
        complete = self.required <= results.keys() and all(
            results[c]['entry_px'] is not None and results[c]['exit_px'] is not None for c in self.required)
        trusted = all(r['sequence_valid'] for r in results.values())
        synchronized = product['association_verified']
        if not complete:
            reasons.append('Required cameras have incomplete/missing entry or exit boundaries')
        if not trusted:
            reasons.append('Frame sequence contains gaps or acquisition errors')
        if not synchronized:
            reasons.append('Multi-camera product association is provisional; shared trigger origin is unverified')
        width = length = None
        if len(self.cameras) == 1 and per_camera:
            single = next(iter(per_camera.values()))
            width, length = single['width_mm'], single['length_mm']
        elif complete and trusted and synchronized:
            # All participating cameras require calibrated positions/scales.
            calibrated = all(all(self.cameras[c].get(k) is not None for k in
                             ('pixels_per_mm_x', 'pixels_per_mm_y', 'x_offset_mm', 'y_offset_mm'))
                             for c in results)
            if calibrated:
                if lows and highs and max(highs) > min(lows):
                    width = max(highs) - min(lows)
                if entries and exits and np.median(exits) > np.median(entries):
                    length = float(np.median(exits) - np.median(entries))
            else:
                reasons.append('Camera scales or global offsets are not configured')
        if width is None:
            reasons.append('Width unavailable: both cross-product sides and valid calibration are required')
        if length is None:
            reasons.append('Length unavailable: entry/exit, valid sequence and calibration are required')
        return {'width_mm': width, 'length_mm': length, 'per_camera': per_camera,
                'boundary_convention': cfg['measurement_boundary'],
                'complete_boundaries': complete, 'sequence_valid': trusted,
                'association_verified': synchronized, 'notes': reasons}

    def write_product(self, ordinal, shutdown=False):
        product = self.products[ordinal]
        dimensions = self.calculate_dimensions(product)
        ended = self.required <= product['camera_results'].keys() and all(
            product['camera_results'][c]['exit_px'] is not None for c in self.required)
        status = 'complete' if ended and dimensions['complete_boundaries'] else ('incomplete' if shutdown else 'collecting')
        if status == 'complete' and not dimensions['association_verified']:
            status = 'provisional'
        if status == 'complete' and not dimensions['sequence_valid']:
            status = 'untrusted_sequence'
        rows = sorted(product['frames'].values(), key=lambda r: (r['grid_row'], r['grid_column']))
        public = {'sample_id': f'product_{ordinal:04d}', 'status': status,
                  'grid_row_definition': 'source-frame index minus this camera sample start index',
                  'dimensions': dimensions, 'frames': rows}
        json_write(product['folder'] / 'product.json', public)
        with (product['folder'] / 'frames.csv').open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['camera_id', 'frame_index', 'grid_row', 'grid_column', 'scan_origin_px', 'scan_origin_mm', 'camera_x_offset_mm', 'paths', 'edge_count'])
            writer.writeheader()
            for row in rows:
                writer.writerow({**row, 'paths': json.dumps(row['paths'])})
        product['closed'] = ended

    def save_preview(self, image, edges, cid, index, tracks):
        # Render first, then draw at preview resolution so labels/lines remain visible.
        im = Image.fromarray(gray8(image, self.cfg.get('input_max_value'))).convert('RGB')
        width, height = im.size
        im.thumbnail((1000, 1100))
        sx, sy = im.width / width, im.height / height
        try:
            font = ImageFont.load_default(size=14)
        except TypeError:
            font = ImageFont.load_default()
        header_height = 32 + 24 * max(1, len(edges))
        canvas = Image.new('RGB', (max(580, im.width), im.height + header_height), '#151515')
        canvas.paste(im, (0, header_height))
        draw = ImageDraw.Draw(canvas)
        draw.text((8, 7), f'{cid} f{index:08d} | {len(edges)} band(s) | '
                  f'{"assigned" if tracks else "not assigned to a product"}', fill='white', font=font)
        if not edges:
            draw.text((8, 32), 'No bands passed detector thresholds.', fill='#ffbc60', font=font)
        for n, e in enumerate(edges):
            color = '#00ff70' if e.get('event') == 'entry' else '#ff9c20'
            axis = e['axis']
            label = e.get('event') or e.get('cross_side') or e['side'] or 'side unresolved'
            name = 'vertical' if axis == 'x' else 'horizontal'
            draw.text((8, 32 + 24 * n),
                      f'{name}: {axis}={e["low"]}..{e["high"]} | {label}',
                      fill=color, font=font)
            if axis == 'x':
                box = (int(e['low'] * sx), header_height + int(e['span_start'] * sy),
                       int(e['high'] * sx), header_height + int(e['span_end'] * sy))
            else:
                box = (int(e['span_start'] * sx), header_height + int(e['low'] * sy),
                       int(e['span_end'] * sx), header_height + int(e['high'] * sy))
            draw.rectangle(box, outline=color, width=2)
        path = self.session / 'previews' / cid / f'{cid}_f{index:08d}.png'
        path.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(path)
        for track in ([] if self.cfg.get('flat_product_folders') else tracks):
            target = self.products[track['ordinal']]['folder'] / 'previews' / path.name
            link_or_copy(path, target)

    def invalidate_sequence(self, cid, message, index=None):
        state = self.states[cid]
        state['sequence_valid'] = False
        self.error(cid, message, index)
        current = state['current']
        if current:
            current['sequence_valid'] = False
            product = self.products[current['ordinal']]
            if cid in product['camera_results']:
                product['camera_results'][cid]['sequence_valid'] = False
            self.write_product(current['ordinal'])

    def finish(self):
        for ordinal in self.products:
            self.write_product(ordinal, shutdown=True)


def create_session(cfg, mode):
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    session = Path(cfg['output_root']) / stamp
    session.mkdir(parents=True, exist_ok=False)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
                        handlers=[logging.StreamHandler(), logging.FileHandler(session / 'acquisition_log.txt', encoding='utf-8')], force=True)
    json_write(session / 'session.json', {'started': datetime.now().astimezone().isoformat(),
                                        'mode': mode, 'config': cfg})
    logging.info('Session: %s', session)
    return session


def extract_index(path):
    stem = path.stem
    for pattern in (r'(?:^|_)f(\d+)(?:_|$)', r'_local_(\d+)(?:_|$)', r'^(\d+)(?:_|$)'):
        match = re.search(pattern, stem)
        if match:
            return int(match.group(1))
    raise ValueError(f'Cannot extract source-frame index: {path.name}')


def run_offline(cfg, folder, already_split=None):
    source = Path(folder).resolve()
    if not source.is_dir():
        raise ValueError(f'Offline input is not a directory: {source}')
    cameras, jobs = [], []
    for i, cam in enumerate(cfg['cameras'][:cfg['num_cameras']]):
        candidates = [source / cam['id'], source / f'camera_{i}']
        camera_dir = next((p for p in candidates if p.is_dir()), None)
        if camera_dir is None and i == 0:
            camera_dir = source
        if camera_dir is None:
            continue
        paths = [p for p in camera_dir.iterdir() if p.is_file() and p.suffix.lower() in EXTENSIONS]
        if already_split:
            # Generic numeric names are allowed; exclude explicitly opposite parity.
            opposite = 'odd' if already_split == 'even' else 'even'
            paths = [p for p in paths if not re.search(rf'_{opposite}(?:_cols)?$', p.stem)]
        elif any(re.search(r'_(even|odd)(?:_cols)?$', p.stem) for p in paths):
            raise ValueError('Split inputs found: specify --already-split even or odd; use raw input otherwise')
        if not paths:
            continue
        seen = set()
        for path in paths:
            index = extract_index(path)
            if index in seen:
                raise ValueError(f'Duplicate index {index} for {cam["id"]}; select one capture/parity')
            seen.add(index)
            jobs.append((index, cam['grid_column'], cam['id'], path))
        cameras.append(cam)
    if not jobs:
        raise ValueError('No matching images found')
    session = create_session(cfg, 'offline')
    pipeline = ProductPipeline(cfg, session, cameras)
    try:
        for index, _, cid, path in sorted(jobs):
            pipeline.process(cid, index, read_image(path), {'source_path': str(path)}, already_split)
    finally:
        pipeline.finish()
    return session


def load_pfs(camera, path, pylon, session):
    if not Path(path).is_file():
        raise FileNotFoundError(f'PFS file not found: {path}')
    try:
        pylon.FeaturePersistence.Load(str(path), camera.GetNodeMap(), True)
        return
    except Exception:
        logging.exception('PFS load failed; retrying sanitized horizontal-binning entries')
    lines = Path(path).read_text(encoding='utf-8').splitlines(keepends=True)
    sanitized = []
    for line in lines:
        parts = line.rstrip('\r\n').split('\t')
        if len(parts) >= 3 and parts[0] in {'BinningHorizontalMode', 'BinningHorizontal'} and parts[1].startswith('{') and parts[1].endswith('}'):
            line = f'{parts[0]}\t{parts[2]}\n'
        sanitized.append(line)
    fd, temp = tempfile.mkstemp(suffix='.pfs', dir=session)
    os.close(fd)
    try:
        Path(temp).write_text(''.join(sanitized), encoding='utf-8')
        pylon.FeaturePersistence.Load(temp, camera.GetNodeMap(), True)
    finally:
        Path(temp).unlink(missing_ok=True)


def set_parameter(camera, name, value, stream=False):
    try:
        node = (camera.GetStreamGrabberNodeMap() if stream else camera.GetNodeMap()).GetNode(name)
        if node is None:
            raise ValueError('Unavailable node')
        node.SetValue(value)
        logging.info('%s=%s', name, value)
    except Exception as exc:
        logging.warning('Could not set %s: %s', name, exc)


def build_camera_registry(cfg, devices):
    by_serial = {str(d.GetSerialNumber()): d for d in devices}
    requested = cfg['cameras'][:cfg['num_cameras']]
    reserved = {str(c['serial']) for c in requested if c.get('serial')}
    unused = iter(sorted(set(by_serial) - reserved))
    registry = []
    for settings in requested:
        serial = str(settings['serial']) if settings.get('serial') else next(unused, None)
        if serial not in by_serial:
            logging.warning('%s: requested camera unavailable (%s)', settings['id'], serial)
            continue
        cam = {**settings, 'serial': serial}
        registry.append((cam, by_serial[serial]))
    return registry


def run_live(cfg):
    try:
        from pypylon import pylon, genicam
    except ImportError as exc:
        raise RuntimeError('Live acquisition needs pypylon: pip install pypylon') from exc
    session = create_session(cfg, 'live')
    factory = pylon.TlFactory.GetInstance()
    registry = build_camera_registry(cfg, factory.EnumerateDevices())
    if not registry:
        raise RuntimeError('No matching cameras detected')
    stop = threading.Event()
    work = queue.Queue(maxsize=cfg['queue_size'])
    opened, threads = [], []
    pipeline = None
    worker = None
    fatal = []
    try:
        for settings, device in registry:
            camera = pylon.InstantCamera(factory.CreateDevice(device))
            try:
                camera.Open()
                load_pfs(camera, settings.get('pfs_file') or cfg['pfs_file'], pylon, session)
                camera.MaxNumBuffer.Value = cfg['camera_max_num_buffer']
                # Basler Stream Grabber Parameters: FrameRetention and PacketTimeout are ms.
                # https://docs.baslerweb.com/stream-grabber-parameters
                set_parameter(camera, 'FrameRetention', cfg['stream_frame_retention_ms'], stream=True)
                set_parameter(camera, 'PacketTimeout', cfg['stream_packet_timeout_ms'], stream=True)
                opened.append((settings, camera))
                logging.info('%s serial=%s shape=%sx%s', settings['id'], settings['serial'], camera.Width.Value, camera.Height.Value)
            except Exception:
                camera.Close()
                raise  # Configuration failure must not silently renumber/drop a configured camera.
        pipeline = ProductPipeline(cfg, session, [s for s, _ in opened])
        json_write(session / 'camera_registry.json', [s for s, _ in opened])
        def consume():
            failed = False
            while True:
                item = work.get()
                try:
                    if item is None:
                        return
                    if not failed:
                        try:
                            pipeline.process(*item)
                        except Exception as exc:
                            try:
                                pipeline.error(item[0], f'Processing/writing failed: {exc}', item[1])
                            except Exception:
                                logging.exception('Could not persist processing error')
                            fatal.append(exc)
                            failed = True
                            stop.set()
                    # Drain queued items after fatal failure to unblock producers.
                finally:
                    work.task_done()
        worker = threading.Thread(target=consume, name='save-and-process')
        worker.start()
        def acquire(settings, camera):
            cid, index, sequence_error = settings['id'], 0, False
            try:
                while not stop.is_set() and camera.IsGrabbing():
                    result = None
                    try:
                        result = camera.RetrieveResult(cfg['grab_timeout_ms'], pylon.TimeoutHandling_ThrowException)
                        if not result.GrabSucceeded():
                            # Feed error through metadata on the next successful frame.
                            sequence_error = True
                            error = result.GetErrorDescription()
                            while True:
                                try:
                                    work.put((cid, index, None, {'sequence_error': True, 'error': error}), timeout=.5)
                                    break
                                except queue.Full:
                                    if fatal:
                                        return
                            index += 1
                            continue
                        metadata = {'host_received_ns': time.time_ns(), 'sequence_error': sequence_error}
                        for field, method in [('block_id', 'GetBlockID'), ('camera_timestamp_ticks', 'GetTimeStamp')]:
                            try:
                                metadata[field] = int(getattr(result, method)())
                            except Exception:
                                metadata[field] = None
                        image = result.Array.copy()
                        # Release the device buffer before potentially blocking on disk backpressure.
                        result.Release()
                        result = None
                        while True:
                            try:
                                work.put((cid, index, image, metadata), timeout=0.5)
                                break
                            except queue.Full:
                                if fatal:
                                    return
                        index += 1
                    except genicam.TimeoutException:
                        continue
                    finally:
                        if result is not None:
                            result.Release()
            except Exception as exc:
                logging.exception('%s acquisition failed', cid)
                fatal.append(exc)
                stop.set()
            finally:
                logging.info('%s capture thread stopped after %s source frames', cid, index)
        for _, camera in opened:
            camera.StartGrabbing(pylon.GrabStrategy_OneByOne)
        for settings, camera in opened:
            thread = threading.Thread(target=acquire, args=(settings, camera), name=f'grab-{settings["id"]}')
            threads.append(thread)
            thread.start()
        logging.info('Acquiring. Press Ctrl+C to stop; queued frames will be drained.')
        while not stop.wait(0.5):
            if not any(t.is_alive() for t in threads):
                break
    except KeyboardInterrupt:
        logging.info('Stop requested')
    finally:
        stop.set()
        # RetrieveResult has a bounded timeout. Join producers BEFORE signaling the consumer.
        for thread in threads:
            thread.join()
        for _, camera in opened:
            try:
                if camera.IsGrabbing():
                    camera.StopGrabbing()
            except Exception:
                logging.exception('StopGrabbing failed')
        if worker:
            work.put(None)
            work.join()
            worker.join()
        for _, camera in opened:
            camera.Close()
        if pipeline:
            if fatal:
                for cid, state in pipeline.states.items():
                    if state['current']:
                        pipeline.invalidate_sequence(cid, 'Capture stopped with an acquisition/processing error')
            pipeline.finish()
    if fatal:
        raise RuntimeError(f'Acquisition stopped with error; inspect {session}: {fatal[0]}')
    return session


def self_test():
    """Hardware-free assertions exercise detection, splitting, tracking and metrics."""
    cfg = load_config()
    cfg.update(num_cameras=1, save_previews=False, split_axis=0, scan_axis=0)
    cam = cfg['cameras'][0]
    cam.update(pixels_per_mm_x=2.0, pixels_per_mm_y=4.0, x_offset_mm=0, y_offset_mm=0)
    d = cfg['detector']
    d.update(min_border_width_px=3, max_border_width_px=20, opening_line_fraction=.12,
             min_line_fraction=.10, shoulder_gap_px=8)
    # Raw source 256x256, split height 128. Borders are 8 raw pixels thick.
    def frame(kind):
        im = np.full((256, 256), 110, dtype=np.uint8)
        if kind == 'start':
            im[64:, 40:48] = 5
            im[64:, 208:216] = 5
            im[64:72, 40:216] = 5
        elif kind == 'middle':
            im[:, 40:48] = 5
            im[:, 208:216] = 5
        elif kind == 'end':
            im[:192, 40:48] = 5
            im[:192, 208:216] = 5
            im[184:192, 40:216] = 5
        return im
    im = np.arange(35).reshape(5, 7)
    for axis in (0, 1):
        parts = split_even_odd(im, axis)
        restored = np.empty_like(im)
        a, b = [slice(None)] * 2, [slice(None)] * 2
        a[axis], b[axis] = slice(0, None, 2), slice(1, None, 2)
        restored[tuple(a)], restored[tuple(b)] = parts['even'], parts['odd']
        assert np.array_equal(restored, im)
    assert not detect_frame_boundaries(np.full((256, 256), 110, np.uint8), cfg)
    with tempfile.TemporaryDirectory() as directory:
        pipeline = ProductPipeline(cfg, directory, [cam])
        for index, kind in enumerate(('start', 'middle', 'end')):
            pipeline.process('c1', index, frame(kind))
        pipeline.finish()
        product = json.loads((Path(directory) / 'products/product_0001/product.json').read_text())
        assert product['status'] == 'complete', product
        assert len(product['frames']) == 3
        dims = product['dimensions']
        assert abs(dims['width_mm'] - 88) <= 2, dims
        assert abs(dims['length_mm'] - 160) <= 2, dims
        # Missing index is preserved and prevents a trusted length.
        other = Path(directory) / 'gapped'
        other.mkdir()
        gapped = ProductPipeline(cfg, other, [cam])
        gapped.process('c1', 0, frame('start'))
        gapped.process('c1', 2, frame('end'))
        gapped.finish()
        p = json.loads((other / 'products/product_0001/product.json').read_text())
        assert not p['dimensions']['sequence_valid']
        assert p['dimensions']['length_mm'] is None
        # Terminal failed grab must invalidate an active product even with no later success.
        failed_dir = Path(directory) / 'failed'
        failed_dir.mkdir()
        failed = ProductPipeline(cfg, failed_dir, [cam])
        failed.process('c1', 0, frame('start'))
        failed.process('c1', 1, None, {'error': 'simulated incomplete grab'})
        failed.finish()
        assert not failed.products[1]['camera_results']['c1']['sequence_valid']
        # Both boundaries within one frame, followed by a second distinct product.
        small = np.full((256, 256), 110, np.uint8)
        small[40:216, 40:48] = 5
        small[40:216, 208:216] = 5
        small[40:48, 40:216] = 5
        small[208:216, 40:216] = 5
        small_dir = Path(directory) / 'small'
        small_dir.mkdir()
        one = ProductPipeline(cfg, small_dir, [cam])
        one.process('c1', 0, small)
        one.process('c1', 1, frame('blank'))
        one.process('c1', 2, small)
        one.finish()
        assert len(one.products) == 2
        assert one.calculate_dimensions(one.products[1])['complete_boundaries']
        # Six cameras, two samples, calibrated shared origin and exterior side cameras.
        multi_cfg = copy.deepcopy(cfg)
        multi_cfg.update(num_cameras=6, synchronization='shared_trigger')
        for i, camera in enumerate(multi_cfg['cameras']):
            camera.update(pixels_per_mm_x=2., pixels_per_mm_y=4.,
                          x_offset_mm=100. * i, y_offset_mm=0.,
                          cross_edge_role='auto' if i in (0, 5) else 'none')
        multi_dir = Path(directory) / 'multi'
        multi_dir.mkdir()
        multi = ProductPipeline(multi_cfg, multi_dir, multi_cfg['cameras'])
        for index, kind in enumerate(('start', 'middle', 'end', 'blank', 'start', 'middle', 'end')):
            for i, camera in enumerate(multi_cfg['cameras']):
                sample = frame(kind)
                # Erase opposite side border without erasing transverse scan boundaries.
                if i != 0:
                    sample[:, 40:48] = 110
                if i != 5:
                    sample[:, 208:216] = 110
                multi.process(camera['id'], index, sample)
        multi.finish()
        assert len(multi.products) == 2, multi.products.keys()
        for product in multi.products.values():
            dimensions = multi.calculate_dimensions(product)
            assert dimensions['association_verified'] and dimensions['complete_boundaries'], dimensions
            assert len(product['frames']) == 18
            assert abs(dimensions['width_mm'] - 588.) < 3, dimensions
            assert abs(dimensions['length_mm'] - 160.) < 2, dimensions
        # Swapping image axes preserves geometry when both axis settings are changed.
        transposed_cfg = copy.deepcopy(cfg)
        transposed_cfg.update(split_axis=1, scan_axis=1)
        transpose_dir = Path(directory) / 'transposed'
        transpose_dir.mkdir()
        transposed = ProductPipeline(transposed_cfg, transpose_dir, [cam])
        for index, kind in enumerate(('start', 'middle', 'end')):
            transposed.process('c1', index, frame(kind).T)
        transposed.finish()
        dims = transposed.calculate_dimensions(transposed.products[1])
        assert abs(dims['width_mm'] - 88.) < 2 and abs(dims['length_mm'] - 160.) < 2, dims
        # A lone side-ambiguous vertical band must remain visible in diagnostics,
        # even though it cannot safely start/complete a product.
        diagnostic_cfg = copy.deepcopy(cfg)
        diagnostic_cfg['save_previews'] = True
        diagnostic_dir = Path(directory) / 'diagnostic'
        diagnostic_dir.mkdir()
        diagnostic = ProductPipeline(diagnostic_cfg, diagnostic_dir, [cam])
        lone_bar = np.full((256, 256), 110, np.uint8)
        lone_bar[:, 120:128] = 5
        diagnostic.process('c1', 28, lone_bar)
        diagnostic.finish()
        assert not diagnostic.products
        diagnostic_record = json.loads((diagnostic_dir / 'detections/c1/c1_f00000028.json').read_text())
        assert diagnostic_record['detected_vertical_bands'] == 1
        assert diagnostic_record['tracking_status'] == 'edges_detected_without_product_assignment'
        assert (diagnostic_dir / 'previews/c1/c1_f00000028.png').is_file()
        diagnostic.process('c1', 29, frame('blank'))
        assert (diagnostic_dir / 'previews/c1/c1_f00000029.png').is_file()
    print('Self-test passed: splitting, blank rejection, multi-frame/single-frame products, dimensions, '
          'failed/missing frames, six-camera/two-product grouping, transposed axes, and previews without product assignment.')


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--write-config', type=Path)
    parser.add_argument('--offline', type=Path)
    parser.add_argument('--already-split', choices=['even', 'odd'])
    parser.add_argument('--output', type=Path, help='Override output_root')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    cfg = load_config(args.config)
    if args.write_config:
        json_write(args.write_config, cfg)
        print(f'Configuration written: {args.write_config}')
        return
    if args.output:
        cfg['output_root'] = str(args.output)
    if args.already_split and not args.offline:
        parser.error('--already-split is only supported for offline replay')
    session = run_offline(cfg, args.offline, args.already_split) if args.offline else run_live(cfg)
    print(f'Finished: {session}')


if __name__ == '__main__':
    main()
