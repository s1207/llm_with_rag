"""Headless paired-image folder processor for an existing Dash/server application.
No UI and no camera acquisition. Use FolderProcessor.start()/stop()/status().
"""
import json
import logging
import queue
import re
import threading
import time
from pathlib import Path
import camera

PAIR = re.compile(r'^(.*)_(even|odd)\.(?:tif|tiff)$', re.I)


def locate(path, root, cams):
    """Keep acquisition directories separate when frame counters reset."""
    for i, cam in enumerate(cams):
        for ancestor in path.parents:
            if ancestor == root.parent:
                break
            if ancestor.name in {cam['id'], f'camera_{i}', str(cam.get('serial') or '')}:
                return ancestor.parent, cam['id']
    for cam in cams:
        if path.name.startswith(cam['id'] + '_'):
            return path.parent, cam['id']
    if len(cams) == 1:
        return path.parent, cams[0]['id']
    return None


def watch(config_path, source, output, stop, emit, existing=True, poll=1., settle=2., gap_wait=30., baseline=None):
    cfg = camera.load_config(config_path)
    cfg.update(output_root=str(output), flat_product_folders=True)
    cfg['save_raw'] = False
    source, output = Path(source).resolve(), Path(output).resolve()
    if not source.is_dir():
        raise ValueError('Input folder does not exist')
    if output == source or output.is_relative_to(source):
        raise ValueError('Output must be outside the watched input folder')
    if cfg['rotation_k'] or cfg['flip_x'] or cfg['flip_y']:
        raise ValueError('Already-split inputs must be pre-oriented; set rotation/flips to zero')
    cams = cfg['cameras'][:cfg['num_cameras']]
    # An explicit baseline prevents accidentally importing old frames in new-files-only mode.
    if baseline is None:
        baseline = {str(p.resolve()) for p in source.rglob('*') if p.is_file()} if not existing else set()
    signatures, ready_at, contexts, done = {}, {}, {}, set()
    waits = {}
    try:
        emit('Watching. Waiting for stable even/odd pairs...')
        while not stop.is_set():
            pairs = {}
            pending = set()
            for path in source.rglob('*'):
                if not path.is_file() or str(path.resolve()) in baseline:
                    continue
                match = PAIR.match(path.name)
                if not match:
                    continue
                found = locate(path, source, cams)
                if found is None:
                    continue
                scope, cid = found
                index = camera.extract_index(path)
                key = (str(scope), cid, index)
                if key in done:
                    continue
                pending.add(key)
                try:
                    stat = path.stat()
                except FileNotFoundError:
                    continue
                signature = (stat.st_size, stat.st_mtime_ns)
                pkey = str(path)
                if signatures.get(pkey) != signature:
                    signatures[pkey] = signature
                    ready_at[pkey] = time.monotonic()
                if stat.st_size and time.monotonic() - ready_at[pkey] >= settle:
                    pairs.setdefault(key, {})[match.group(2).lower()] = path
            for key in sorted(pairs, key=lambda k: (k[0], k[2], k[1])):
                if stop.is_set():
                    break
                paths = pairs[key]
                if paths.keys() < {'even', 'odd'}:
                    continue
                scope, cid, index = key
                if any(k[0] == scope and k[1] == cid and k[2] < index and k not in done for k in pending):
                    continue  # Never overtake an earlier incomplete/unsettled pair.
                context = contexts.get(scope)
                if context is None:
                    session = camera.create_session(cfg, 'continuous-paired-folder')
                    context = camera.ProductPipeline(cfg, session, cams)
                    contexts[scope] = context
                    camera.json_write(session / 'input_scope.json', {'input_directory': scope})
                    emit(f'New capture: {scope}\nOutput: {session}')
                previous = context.states[cid]['last_index']
                if previous is not None and index <= previous:
                    emit(f'Ignoring late/duplicate {cid} frame {index}; already passed frame {previous}.')
                    done.add(key)
                    continue
                if previous is not None and index != previous + 1:
                    waits.setdefault(key, time.monotonic())
                    if time.monotonic() - waits[key] < gap_wait:
                        continue
                    emit(f'{cid}: missing frame(s) before {index}; sequence will be marked untrusted.')
                try:
                    even, odd = camera.read_image(paths['even']), camera.read_image(paths['odd'])
                except Exception as exc:
                    emit(f'Waiting for readable pair {cid} frame {index}: {exc}')
                    continue
                context.process(cid, index, even,
                                {'source_even': str(paths['even']), 'source_odd': str(paths['odd'])},
                                already_split='even', paired_odd=odd)
                done.add(key)
                emit(f'{cid} frame {index}: saved even + odd; {len(context.products)} sample(s).')
            stop.wait(poll)
    finally:
        for pipeline in contexts.values():
            pipeline.finish()
        emit('Stopped. Samples without an end boundary remain marked incomplete.')


class FolderProcessor:
    """Own ONE instance per backend process; callbacks must reuse that instance.

    start() returns immediately and ignores repeat starts while running/stopping.
    stop() requests clean shutdown; status() reports asynchronous progress/errors.
    This object does not coordinate multiple Gunicorn workers or replicas.
    """
    def __init__(self, config_path, input_parent, output_parent, include_existing=False):
        self.config_path = str(config_path)
        self.input_parent = Path(input_parent).resolve()
        self.output_parent = Path(output_parent).resolve()
        self.include_existing = include_existing
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self._messages = []
        self._state = 'idle'
        self._error = None

    def _emit(self, message):
        with self._lock:
            self._messages.append(message)
            self._messages = self._messages[-100:]

    def start(self):
        with self._lock:
            if self._thread and self._thread.is_alive():
                return False
            camera.load_config(self.config_path)
            self.input_parent.mkdir(parents=True, exist_ok=True)
            if self.output_parent == self.input_parent or self.output_parent.is_relative_to(self.input_parent):
                raise ValueError('Output must be outside the input folder')
            # Snapshot BEFORE camera acquisition starts, so newly written frames
            # cannot be mistaken for pre-existing files by a delayed worker.
            baseline = ({str(p.resolve()) for p in self.input_parent.rglob('*') if p.is_file()}
                        if not self.include_existing else set())
            self._stop.clear()
            self._state, self._error = 'running', None
            def run():
                try:
                    watch(self.config_path, self.input_parent, self.output_parent,
                          self._stop, self._emit, self.include_existing, baseline=baseline)
                except Exception as exc:
                    logging.exception('Folder processor failed')
                    with self._lock:
                        self._error = str(exc)
                    self._emit(f'ERROR: {exc}')
                finally:
                    with self._lock:
                        self._state = 'error' if self._error else 'stopped'
            self._thread = threading.Thread(target=run, name='paired-folder-processor', daemon=False)
            self._thread.start()
            return True

    def stop(self, wait=False, timeout=None):
        with self._lock:
            self._stop.set()
            thread = self._thread
            if thread and thread.is_alive():
                self._state = 'stopping'
        if wait and thread and thread is not threading.current_thread():
            thread.join(timeout)
        return self.status()

    def status(self):
        with self._lock:
            return {'state': self._state, 'running': bool(self._thread and self._thread.is_alive()),
                    'error': self._error, 'messages': list(self._messages)}
